import React from 'react';
const RemoteButton = React.lazy(() => import('custom/Button'));

const App = () => (
  <div>
    <h2>Host</h2>
    <React.Suspense fallback="Loading Button">
      <RemoteButton text="this is from remote" handleButtonClick={() => window.alert("Hello from remote")}/>
    </React.Suspense>
  </div>
);

export default App;