const { dependencies } = require('./package.json');

module.exports = {
  name: 'home',
  remotes: {
    custom: 'custom@http://localhost:3001/remoteEntry.js',
  },
  shared: {
    ...dependencies,
    react: {
      singleton: true,
      requiredVersion: dependencies['react'],
    },
    'react-dom': {
      singleton: true,
      requiredVersion: dependencies['react-dom'],
    },
  },
};