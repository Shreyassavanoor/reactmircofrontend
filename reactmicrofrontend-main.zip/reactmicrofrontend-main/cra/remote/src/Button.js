import React from 'react';

export default function SurveyActions({text = "Remote button", handleButtonClick}) {
    return (
        <div>
            <button onClick={() => handleButtonClick()}>{text}</button>
        </div>
    );
}