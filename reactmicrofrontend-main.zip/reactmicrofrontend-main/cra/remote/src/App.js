import React from 'react';
import LocalButton from './Button';

const App = () => (
  <div>
    <h2>Remote</h2>
    <LocalButton />
  </div>
);

export default App;