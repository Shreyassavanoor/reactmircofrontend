This project aims at creating a micro frontend with "module federation plugin".

Resources:
1. https://github.com/module-federation/module-federation-examples/tree/master/cra: Official example with create react app
2. https://blog.developer.adobe.com/transforming-a-huge-monolith-to-micro-frontends-5fdd4179c44f
3. https://blog.dream11engineering.com/how-to-convert-a-huge-frontend-monolith-to-a-micro-frontend-d37f47697235
4. https://tanbt.medium.com/micro-frontend-implementation-part-2-nested-react-apps-dee8d57b60f3
5. https://www.solutelabs.com/blog/migrate-from-monolith-to-micro-frontend
6. https://blog.logrocket.com/build-micro-frontend-application-react/
7. https://stackoverflow.com/questions/67297300/how-to-use-webpack-module-federation-plugin-with-create-react-app-without-ejecti


Project structure:  
cra -> created with "create react app"  
1. Home is the container react application.  
2. Remote is the another react app which exposes   "Button" component and which is integrated in Home app.


craeject -> created with "create react app" but then ejected using command "npm eject" [In walmart most of apps are ejected].  
1. Home is the container react application.  
2. Remote is the another react app which exposes   "Button" component and which is integrated in Home app.  


Steps to run:
1. Clone the repo
2. Navigate to each "Home" and "remote". Install node modules by executing command "npm i".
3. Run home app in port 3000 and remote in 3001.
