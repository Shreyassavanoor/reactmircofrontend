Steps to make ejected app working as microfrontend
1. Create "moduleFederation config" file in home and remote. In remote expose the components needed to consume in home.
2. Create "webpack config" file and use moduleFederation plugin from the properties of "moduleFederation config file". Repeat same for remote.
3. Change the path name of configFactory in "scripts/build" and "scripts/start" in both home and remote. 
Before: "const configFactory = require('../config/webpack.config')" 
After: "const configFactory = require('../webpack.config')"
4. Create "bootstrap.js" file and import it in "index.js".
5. Run both home and remote.